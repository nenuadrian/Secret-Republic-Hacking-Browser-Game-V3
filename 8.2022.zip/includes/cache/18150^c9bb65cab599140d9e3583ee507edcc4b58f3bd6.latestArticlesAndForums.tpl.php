<?php
/* Smarty version 3.1.45, created on 2022-08-15 19:21:14
  from '/Applications/MAMP/htdocs/Secret-Republic-Hacking-Browser-Game-V3/templates/index/latestArticlesAndForums.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.45',
  'unifunc' => 'content_62fa8e9a960a14_75291816',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '527ff8a367ee57e00d2b6176c0fab10c44d76b86' => 
    array (
      0 => '/Applications/MAMP/htdocs/Secret-Republic-Hacking-Browser-Game-V3/templates/index/latestArticlesAndForums.tpl',
      1 => 1660587509,
      2 => 'file',
    ),
  ),
  'cache_lifetime' => 1,
),true)) {
function content_62fa8e9a960a14_75291816 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="articles-list">
  <div class="row">
     <div class="col-xs-6 cut-text">
        latest news | <strong>none </strong>
     </div>
     <div class="col-xs-6 text-right cut-text">
       <strong>none </strong> | latest event
     </div>
   </div>
</div>




<style>
  .articles-holder
  {
   /* background-color:rgba(53, 129, 195, 0.09); 
                  border:1px solid rgba(53, 129, 195, 0.23);

                  box-shadow: inset 0 0 10px rgba(0,161,250,0.1), 0 3px 5px rgba(0,0,0,0.3);
                    background-color: rgba(53, 129, 195, 0.02);
                    */
                  text-shadow: 0px 0px 10px rgba(0, 149, 255, 0.75);
                    
  }

  .articles-column
  {
    padding:20px;
    opacity:.9;
    transition-property: opacity;
    transition-duration: .3s;
    transition-timing-function: ease-in;

    -webkit-transition-property: opacity;
    -webkit-transition-duration: .3s;
    -webkit-transition-timing-function: ease-in;

    -moz-transition-property: opacity;
    -moz-transition-duration: .3s;
    -moz-transition-timing-function: ease-in;

    -o-transition-property: opacity;
    -o-transition-duration: .3s;
    -o-transition-timing-function: ease-in;

  }

  .articles-column .bottom-line
  {
    height:15px;
     
      text-align:center;
     
  }
  .articles-column .bottom-line .line{
 margin-bottom: 7px;
  width: 20%;
  border-bottom: 2px solid rgba(66, 139, 202, 0.3);
  padding: 0;
  display: inline-block;
  }
  .articles-column:hover{
    opacity:1;
  }
  .articles-column p{
    font-size:15px; 

      border-top: 2px solid rgba(66, 139, 202, 0.3);
  padding: 12px;
  border-radius: 5px;
    background-color: rgba(39, 123, 216, 0.05);
    margin:0;

padding-left:20px;
padding-right:20px;
font-weight:bold;
letter-spacing: 2px;
  }

  .articles-list
  {
      background-color: rgba(39, 123, 216, 0.05);
     font-size:13px;
       line-height: 35px;
  padding: 20px;
  border-left: 2px solid rgba(66, 139, 202, 0.3);
  border-right: 2px solid rgba(66, 139, 202, 0.3);
  border-radius: 5px;
  margin: 0;
  padding-top: 5px;
  padding-bottom: 5px;

  }


  .articles-list a{
    
      text-overflow: ellipsis;
  white-space: nowrap;
  overflow: hidden;
  text-transform:uppercase;
  }

  .articles-column .articles-list
  {
    padding-bottom:0px;
    border-top-left-radius:0;
    border-top-right-radius:0;
  }
  .articles-column .articles-list a{
    display:block;
  }

  .articles-column .articles-column-content
  {
      -moz-box-shadow: 0 0 70px rgba(79, 182, 255, 0.1);
  -webkit-box-shadow: 0 0 40px rgba(79, 182, 255, 0.1);
  box-shadow: 0 0 40px rgba(79, 182, 255, 0.1);
  -ms-filter: "progid:DXImageTransform.Microsoft.Shadow(Strength=3, Direction=0, Color='rgba(79, 182, 255, 0.1)')";
  filter: progid:DXImageTransform.Microsoft.Shadow(Strength=3,Direction=0,Color='rgba(79, 182, 255, 0.1)');
  }
</style>
  <div class="row">
    <div class="col-md-12">

      <div class="articles-holder">
        <div class="row">
          <div class="col-md-4 articles-column">
            <div class="articles-column-content">
              <p>
                <a href="http://localhost:8888/Secret-Republic-Hacking-Browser-Game-V3/public_html/blogs/latestArticles/emilia">
                  LATEST ARTICLES
                </a>
              </p>
              <div class="articles-list">
	      	                        No articles yet!
                                                      <div class="bottom-line">
                    <div class="line"></div>
                  </div>
              </div>

             </div>
          </div>
          <div class="col-md-4 articles-column text-center">
            <div class="articles-column-content">
              <p>
                <a href="http://localhost:8888/Secret-Republic-Hacking-Browser-Game-V3/public_html/organization/view/forum/">
                  ORG <small><span class="glyphicon glyphicon-tower"></span></small> FORUM
                </a>
              </p>
              <div class="articles-list">
                                    <a href="http://localhost:8888/Secret-Republic-Hacking-Browser-Game-V3/public_html/organization">
                     JOIN AN ORGANIZATION
                   </a>
                                  <div class="bottom-line">
                    <div class="line"></div>
                  </div>
               
              </div>
            </div>
          </div>
          <div class="col-md-4 articles-column text-right">
            <div class="articles-column-content">
              <p>
                <a href="http://localhost:8888/Secret-Republic-Hacking-Browser-Game-V3/public_html/forum">
                  PUBLIC FORUM <small><span class="glyphicon glyphicon-comment"></span></small>
                </a>
              </p>
              <div class="articles-list">
		                          No posts yet!
                                                            <div class="bottom-line">
                    <div class="line"></div>
                  </div>

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <?php }
}
