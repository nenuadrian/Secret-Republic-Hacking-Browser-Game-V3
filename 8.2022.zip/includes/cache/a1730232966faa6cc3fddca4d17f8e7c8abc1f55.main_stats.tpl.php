<?php
/* Smarty version 3.1.45, created on 2022-08-15 19:10:47
  from '/Applications/MAMP/htdocs/Secret-Republic-Hacking-Browser-Game-V3/templates/home/main_stats.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.45',
  'unifunc' => 'content_62fa8c2745e949_77239022',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '3b2074012c83f87d45556c5b703e1972bf804ba3' => 
    array (
      0 => '/Applications/MAMP/htdocs/Secret-Republic-Hacking-Browser-Game-V3/templates/home/main_stats.tpl',
      1 => 1660584956,
      2 => 'file',
    ),
  ),
  'cache_lifetime' => 360,
),true)) {
function content_62fa8c2745e949_77239022 (Smarty_Internal_Template $_smarty_tpl) {
?><br/>
	  <strong><em>1 hackers have recently connected to the Grid</em> </strong>
	   <br/> <br/>
	  <h4>newest organizations && hackers</h4>
                        <a href="http://localhost:8888/Secret-Republic-Hacking-Browser-Game-V3/public_html/profile/hacker/cardinal">cardinal</a>
                                <a href="http://localhost:8888/Secret-Republic-Hacking-Browser-Game-V3/public_html/profile/hacker/cardinal">cardinal</a>
              	  
	  
	  <br/>
	 
	
	  <br/>
    <p>
  latest news | <a href="http://localhost:8888/Secret-Republic-Hacking-Browser-Game-V3/public_html/forum/tid/"></a>
</p>
  last article | <a href="http://localhost:8888/Secret-Republic-Hacking-Browser-Game-V3/public_html/blog/article/"></a>
	  
	 
	  <br/><br/>
	  <strong>Random review</strong> 
	  <em>
	  
	  My first hours after I moved from gaming my life away to become what some people might call a hacker.... Seriously I didn't knew it was that hard, but okay everything new is hard in some way...
		</em><?php }
}
