<?php
/* Smarty version 3.1.45, created on 2022-08-15 18:42:32
  from '/Applications/MAMP/htdocs/Secret-Republic-Hacking-Browser-Game-V3/templates/pages/error.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.45',
  'unifunc' => 'content_62fa85883e0886_60504698',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '50e0a09fd524b6dd8963b7d67e447a59db3a2f72' => 
    array (
      0 => '/Applications/MAMP/htdocs/Secret-Republic-Hacking-Browser-Game-V3/templates/pages/error.tpl',
      1 => 1660584956,
      2 => 'file',
    ),
    '9ebaba507c6378e116668366290842d3681a191a' => 
    array (
      0 => '/Applications/MAMP/htdocs/Secret-Republic-Hacking-Browser-Game-V3/templates/header_home.tpl',
      1 => 1660584956,
      2 => 'file',
    ),
    'f79cdd082a95554fa1f80a43801795172c9b9c99' => 
    array (
      0 => '/Applications/MAMP/htdocs/Secret-Republic-Hacking-Browser-Game-V3/templates/admin/adminNavigation.tpl',
      1 => 1660584956,
      2 => 'file',
    ),
  ),
  'cache_lifetime' => 1800,
),true)) {
function content_62fa85883e0886_60504698 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<meta charset="UTF-8">
	<title>World Timeline  - Secret Republic - Hacking Simulation Browser Based Game - Hacking MORPG</title>
		<link rel="shortcut icon" href="http://localhost:8888/Secret-Republic-Hacking-Browser-Game-V3/public_html/layout/img/favicon.ico" type="image/x-icon">
	<meta name="description" content="An online hacking simulation Massive Multiplayer Online Role Playing Game based on your browser. We aim to provide something new, a fresh browser gameplay experience. The hacker game for you."/>
	<meta name="revisit" content="After 3 days"/>
	<meta name="Expires" content="never"/>
	<meta name="robots" content="INDEX,FOLLOW"/>
	<meta name="language" content="en"/>
	<meta name="page-type" content="browser game, browsergame"/>
	<meta name="author" content="Secret Republic"/>
	<meta name="publisher" content="Secret Republic"/>
	<meta name="copyright" content="Secret Republic"/>
	<meta name="page-topic" content="free online hacking economical social and simulation browser based game"/>
	<meta name="audience" content="all"/>

 <!--<meta name="viewport" content="width=device-width, initial-scale=0.7">-->
<meta name="viewport" content="width=device-width, initial-scale=0.7, maximum-scale=0.8, minimum-scale=0.9, user-scalable=no" />

	<meta property="og:image" content='http://localhost:8888/Secret-Republic-Hacking-Browser-Game-V3/public_html/layout/img/share_logo.png'/>


	<link rel="stylesheet" href="http://localhost:8888/Secret-Republic-Hacking-Browser-Game-V3/public_html/layout/css/reset.css?c=2" type="text/css"/>

    <link href='https://fonts.googleapis.com/css?family=Abel' rel='stylesheet' type='text/css'>

	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.4/css/bootstrap.min.css">

	<link rel="stylesheet" href="http://localhost:8888/Secret-Republic-Hacking-Browser-Game-V3/public_html/layout/css/custom.css?t=fffff" type="text/css"/>
   <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css?c=2" rel="stylesheet">


	

	
 <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>

	<script type="text/javascript">
		url="https://localhost:8888/Secret-Republic-Hacking-Browser-Game-V3/public_html/theWorld/";
		main_url="http://localhost:8888/Secret-Republic-Hacking-Browser-Game-V3/public_html/";
		mobile=false;
		tablet=false;


	</script>

</head>
<body id="body">






<div class="container" >


	 	  <div class="visible-xs visible-sm">
		<div style="padding:30px">
		</div>
	</div>


	<!-- NAVIGATION -->
	
	<div class="row visible-md visible-lg top-container" >
	        <div class="futureNav middle" style="margin-bottom:-15px;">
        <ul>
              <li><a href="http://localhost:8888/Secret-Republic-Hacking-Browser-Game-V3/public_html/rankings" title="Rankings"><span class="glyphicon glyphicon-king"></span></a></li>
              <li class="mid-item"><a href="http://localhost:8888/Secret-Republic-Hacking-Browser-Game-V3/public_html/theWorld" title="Our world" ><span class="glyphicon glyphicon-globe"></span></a></li>
              <li><a href="http://localhost:8888/Secret-Republic-Hacking-Browser-Game-V3/public_html/forum" title="Forums"><span class="glyphicon glyphicon-comment"></span></a></li>
        </ul>
    </div>
    <div class="futureNav">
      <ul>
        <li><a href="http://localhost:8888/Secret-Republic-Hacking-Browser-Game-V3/public_html/"><span class="glyphicon glyphicon-home"></span></a></li>
          <li><a href="http://localhost:8888/Secret-Republic-Hacking-Browser-Game-V3/public_html/register">Join</a></li>
          <li><a href="http://localhost:8888/Secret-Republic-Hacking-Browser-Game-V3/public_html/rankings/type/orgs"><span class="glyphicon glyphicon-tower"></span></a></li>
          <li style="width:70px;"></li>
          <li><a href="http://localhost:8888/Secret-Republic-Hacking-Browser-Game-V3/public_html/rankings/type/blogs">Blogs</a></li>
          <li><a href="http://localhost:8888/Secret-Republic-Hacking-Browser-Game-V3/public_html/blogs/latestArticles/eve">Articles</a></li>
          <li><a href="http://localhost:8888/Secret-Republic-Hacking-Browser-Game-V3/public_html/support">Contact</a></li>
        </ul>
    </div>
        	</div>
	
	<div class="row-fluid hackBody mb10">


			<div class="col-md-12">
			
					<h1 class="text-center weirdHeading">CARDINAL SYSTEM ERROR</h1>
					<div class="row">
					<div class="col-xs-4">
						<div class="text-center"> <img src="http://secretrepublic.net/layout/img/characters/Irene-A.I.png" style=" max-width:240px"> </div>
					</div>
					<div class="col-xs-8">
					<div class="alert alert-error">
						
						ERROR recorded. Please contact us if you think this is a bug!
					
					</div>
					<div class="alert alert-info">
						To track this specific error please provide the following: <strong>ISSUE#</strong> in your inquiry.
					</div>
									<div class="panel panel-glass">
						<div class="panel-heading">debugging</div>
						<div class="panel-body">
							array (<br />
  'errline' => 326,<br />
  'errfile' => '/Applications/MAMP/htdocs/Secret-Republic-Hacking-Browser-Game-V3/includes/vendor/joshcam/mysqli-database-class/MysqliDb.php',<br />
  'page' => 'theWorld',<br />
  'url' => 'https://localhost:8888/Secret-Republic-Hacking-Browser-Game-V3/public_html/theWorld/',<br />
  'errno' => 1,<br />
  'errstr' => 'Uncaught Exception: Connect Error 1045: Access denied for user &#039;root&#039;@&#039;localhost&#039; (using password: NO) in /Applications/MAMP/htdocs/Secret-Republic-Hacking-Browser-Game-V3/includes/vendor/joshcam/mysqli-database-class/MysqliDb.php:326<br />
Stack trace:<br />
#0 /Applications/MAMP/htdocs/Secret-Republic-Hacking-Browser-Game-V3/includes/vendor/joshcam/mysqli-database-class/MysqliDb.php(415): MysqliDb-&gt;connect(&#039;default&#039;)<br />
#1 /Applications/MAMP/htdocs/Secret-Republic-Hacking-Browser-Game-V3/includes/vendor/joshcam/mysqli-database-class/MysqliDb.php(1995): MysqliDb-&gt;mysqli()<br />
#2 /Applications/MAMP/htdocs/Secret-Republic-Hacking-Browser-Game-V3/includes/vendor/joshcam/mysqli-database-class/MysqliDb.php(576): MysqliDb-&gt;_prepareQuery()<br />
#3 /Applications/MAMP/htdocs/Secret-Republic-Hacking-Browser-Game-V3/includes/modules/theWorld.php(38): MysqliDb-&gt;rawQuery(&#039;select (select ...&#039;, Array)<br />
#4 /Applications/MAMP/htdocs/Secret-Republic-Hacking-Browser-Game-V3/public_html/index.php(75): require(&#039;/Applications/M...&#039;)<br />
#5 {main}<br />
  thrown',<br />
  'user_id' => 0,<br />
  'backtrace' => '0',<br />
)
						</div>
					</div>
								<a href="http://localhost:8888/Secret-Republic-Hacking-Browser-Game-V3/public_html/" class="button text-center">GO TO HOME</a>
				</div>
			</div>
	
		
<?php }
}
