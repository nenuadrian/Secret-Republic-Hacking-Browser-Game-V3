<?php
/* Smarty version 3.1.45, created on 2022-08-15 19:19:50
  from '/Applications/MAMP/htdocs/Secret-Republic-Hacking-Browser-Game-V3/templates/footer_home.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.45',
  'unifunc' => 'content_62fa8e4607d9c6_29593670',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5d2fc8aac2f52dae8c5b7af0d94fab40c2582183' => 
    array (
      0 => '/Applications/MAMP/htdocs/Secret-Republic-Hacking-Browser-Game-V3/templates/footer_home.tpl',
      1 => 1660587061,
      2 => 'file',
    ),
    '206c910e0e8cbda3262ad124ace8f9ef6b62980c' => 
    array (
      0 => '/Applications/MAMP/htdocs/Secret-Republic-Hacking-Browser-Game-V3/templates/dialogs/osx_dialog_box.tpl',
      1 => 1660584956,
      2 => 'file',
    ),
  ),
  'cache_lifetime' => 3600,
),true)) {
function content_62fa8e4607d9c6_29593670 (Smarty_Internal_Template $_smarty_tpl) {
?>
      </div> <!-- span -->
      </div> <!-- row -->
	  
	  	  	<a href="http://localhost:8888/Secret-Republic-Hacking-Browser-Game-V3/public_html/rewards" >
	  	<button class="rewards-icon"  title="1 rewards to claim">
		
		
		<span class="glyphicon glyphicon-gift" id="rewards2"></span>
		
		</button></a>
	  	  
	   
		  
	  	  		

<!-- Modal -->
<div class="modal fade" id="myModalmodalPopuptutorial" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
              <div class="modal-header">
		  <a class="close-button" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span></a>
          <h4 class="modal-title" id="myModalLabel">I | Step numero zero</h4>
        </div>
            <div class="modal-body">
        <div style="padding:10px "><p>*applause*</p>
			<p>Welcome, cardinal,</p>
			<p>To the first of a series of mini-tutorials meant to introduce you to this majestic competition.</p>
			<p>Rewards await you at the end of every step.</p>
			<p>First and foremost, go through <a href='http://localhost:8888/Secret-Republic-Hacking-Browser-Game-V3/public_html/pages/page/beginner-tutorial'>a short summary of available interfaces</a>.</p>
			<p><strong>Connecting to your account daily will grant incremental rewards proportional with the number of consecutive days.</strong></p>
			<p>The tutorial icon will keep flashing on the left. Press it when you're done reading the summary.</p></div>
<div class="panel panel-future ">
	<div class="panel-heading ">Rewards</div>
	<div class="panel-body">
	<button disabled><div class="row">
		<div class="col-xs-4">
			25$
		</div>
		<div class="col-xs-4">
			20 EXP
		</div>
		<div class="col-xs-4">
			4 USC
		</div>
		</div>
		</button>
	<br/><div class="alert alert-danger nomargin text-center">
			  	If you skip you will not receive any rewards for this step
			  </div></div>

<form method="post" >
	<button type="submit" name="skipStep" value="go">SKIP STEP I</button>
</form>
</div>


<div class="panel panel-future">

	<div class="panel-body">
	<div class="progress"> <div class="progress-bar" role="progressbar" style="width:5%"> </div> </div>
	</div>
	<div class="panel-footer text-right">Tutorial progress [1/20]</div>
</div>
      </div>
     
    </div>
  </div>
</div>




		
	  
	  	  
	   
 	<script type="text/javascript">$(window).load(function(){
 					
	});
	</script>

 
   

  
      	
		
                <div class="row-fluid mb10">
   				<div class="col-md-12">
				<div style="height:111px"></div>
				</div>
              <div class="col-md-10  ">
              
                <div class="well black ">
				

							<small>&copy; 2022 the secret republic</small>

                </div>
              </div>
              <div class="col-md-2  visible-md visible-lg">
                                  <a href="http://localhost:8888/Secret-Republic-Hacking-Browser-Game-V3/public_html/logout" class="button text-center"><span class="glyphicon glyphicon-off"></span></a>
                              </div>
          
        </div>
       
		
              
			<div class="row-fluid  ">
			  <div class="col-md-12 text-center footer">
			  <br/>
			  <p>
			  
			  
			  <a href="http://localhost:8888/Secret-Republic-Hacking-Browser-Game-V3/public_html/theWorld" title="Stats of the hacking competition"> World stats</a>
				<a href="http://localhost:8888/Secret-Republic-Hacking-Browser-Game-V3/public_html/rankings" title="Hacker rankings">Rankings</a>
				
        <a href="http://localhost:8888/Secret-Republic-Hacking-Browser-Game-V3/public_html/blogs/" title="Hacker blogs">blogs</a>
        <a href="http://localhost:8888/Secret-Republic-Hacking-Browser-Game-V3/public_html/blogs/latestArticles/eve" title="Latest articles">articles</a>
        <a href="http://localhost:8888/Secret-Republic-Hacking-Browser-Game-V3/public_html/frequently-asked-questions" title="Frequently Asked Questions">f.a.q.</a>
        <a href="http://localhost:8888/Secret-Republic-Hacking-Browser-Game-V3/public_html/pages/page/beginner-tutorial">beginner intro</a>

				
				</p>
        <p>
          <a href="http://localhost:8888/Secret-Republic-Hacking-Browser-Game-V3/public_html/pages/page/about">about</a>
        <a href="http://localhost:8888/Secret-Republic-Hacking-Browser-Game-V3/public_html/forum" title="Secret Republic Public Forums">Forums</a>
          <a href="http://localhost:8888/Secret-Republic-Hacking-Browser-Game-V3/public_html/pages/page/media">artwork</a>
          <a href="http://localhost:8888/Secret-Republic-Hacking-Browser-Game-V3/public_html/pages/page/terms-of-service">t.o.s. & privacy</a>
        <a href="http://localhost:8888/Secret-Republic-Hacking-Browser-Game-V3/public_html/support">support</a>

        </p>
			
				<a onclick="scrollToElement('#body');"><span class="glyphicon glyphicon-chevron-up"></span></a>



			  </div>
			</div>
			<div class="row-fluid">
			<div class="col-md-12">
			<div style="height:20px">
			</div>
			</div></div>
		       
	 	</div>

    

	</div>
	

	

	
    
    <script type="text/javascript"  src="//cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.2/html5shiv.js"></script>
	  



    <script type="text/javascript" src="http://localhost:8888/Secret-Republic-Hacking-Browser-Game-V3/public_html/layout/js/global.js?cache=3ffsf44ff"></script>
  
    <script type="text/javascript" src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
    

		  
  
</body>
</html>
<?php }
}
