<?php
/* Smarty version 3.1.45, created on 2022-08-15 19:21:08
  from '/Applications/MAMP/htdocs/Secret-Republic-Hacking-Browser-Game-V3/templates/rankings/rankingsGrid.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.45',
  'unifunc' => 'content_62fa8e943069f5_57605416',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4e9cd6f290ae4ab7640ae7d6fa0c180987d1030a' => 
    array (
      0 => '/Applications/MAMP/htdocs/Secret-Republic-Hacking-Browser-Game-V3/templates/rankings/rankingsGrid.tpl',
      1 => 1660584956,
      2 => 'file',
    ),
  ),
  'cache_lifetime' => 3600,
),true)) {
function content_62fa8e943069f5_57605416 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="mb10">
      <div class="row mb10">
    
            <div class="col-xs-6 ">
                              <a href="http://localhost:8888/Secret-Republic-Hacking-Browser-Game-V3/public_html/rankings"><button>HACKERS</button></a>
                          </div>
            <div class="col-xs-6 ">
                              <a href="http://localhost:8888/Secret-Republic-Hacking-Browser-Game-V3/public_html/rankings/type/orgs"><button>ORGANIZATIONS</button></a>
              
            </div>
 
      </div>
      		</div>
		
	
				
		<div class="text-center">
		   <ul class='pagination'></ul>
		</div><?php }
}
