<?php
/* Nenu Adrian http://nenuadrian.com 2012 */

	$ai=array(
		1 => array(
			"name"=>"Eve",
			"description"=>"Eve",
			"image"=>"eve.png",
			"icon"=>"eve_icon.png",
			"lang_folder"=>"eve",
			"audio_folder"=>"eve",
		),
		
		);

?>