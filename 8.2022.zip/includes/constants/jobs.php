<?php

	$jobs = array(
	
	  1 => array(
	    "name" => "Decrypter",
	    "qgroup_order" =>  1, // this will be matched to what is set on the admin mission screen
	    "story" => "In a world where security is of utmost importance, decrypters are the freelancers of choice.
	    
	    Not always using their pricy skills for the best purposes, they are hired by many individuals to unravel the most inner secrets of powerfully encrypted files and even to recovere data thought to have been lost deep into the digital spaghetti.
	    
	    0's and 1's get a whole new meaning in the world of decrypters."
	  ),
	  2 => array(
	    "name" => "Vulnerability engineer",
	    "qgroup_order" =>  2, // this will be matched to what is set on the admin mission screen
	    "story" => "Ages ago network security was not even taken into consideration until the first black hat hackers sprouted all around like mushrooms after the rain.
	    
	    Today, vulnerabilities are not only unavoidable, but every company's worst nightmare.
	    
	    While some use their abilities to make their way through closed doors, others invest in keeping those doors sealed shut."
	  ),
	
	);