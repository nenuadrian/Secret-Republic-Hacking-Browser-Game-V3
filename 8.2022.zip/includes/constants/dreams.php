<?php
//Nenu Adrian Mircea 2012

$dreams=array(

	1=>array(
		"story"=>"A small girl approaches me. Both her hair and dress are pure white and she seems to be glowing in the blackness surrounding her.<br/>
		 She raises her head, looks into my eyes and whispers: <Br/><br/>
		 \"Every step you'll make will be towards fame and power. You've had a place booked in hell since before the day you were born\" and then she disappears without a trace leaving me in utter darkness.<br/><br/>
		 Her voice lingers in my head, it was so clear, mysterious and the same time kind, in one word, perfect.<br/><br/>
		 What the heck was all that about? No... it can't be!",
	),
	
	2=>array(
		"story"=>"I'm back in my old room. What am I doing here? I haven't seen this place for years now.<br/>
		It's silent. Too silent. I look around and spot a difference. On the wall behind me something is written in red on the entire wall:<br/>
		<br/> \"Survival of the fittest.\" <br/><br/>
		Is that.. is that blood?! I try to look around some more and a spot a body beside the bed. I try to get closer but I can't move from where I'm standing. What the ..? I look and the floor to see that I am sticked to the floor!
		<br/><br/>
		What's happening here? I scream with no sound acutally getting out of my mouth.
		<br/><br/>
		<i>This is the path you have chosen.</i><br/><br/>
		A girl voice says seemingly from all around me. What do you mean? I ask to the wall.<br/><br/>
		<i>It will sometimes be painted with dreams but in the same time it could be covered by bodies</i><br/><br/>
		Who are you? I insist on questioning her.<br/><br/>
		<i>You must live on! You must win, for the sake of us all.</i>, she says, her voice slowly fadding away.
		",
	),
	
	

);


?>