# includes

Hidden files included per need basis by `index.php` and by each other.

## constants

General control over game balance.
